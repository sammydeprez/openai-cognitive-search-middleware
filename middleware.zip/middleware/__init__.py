import azure.functions as func
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from services import request_handler as rh
from services import openai_handler as oai
import pandas as pd
import os
import json

 
app = FastAPI()

@app.post("/indexes/{index}/docs/search")
async def search_docs(req: Request) -> Response:
    response = await rh.forward_req(req)

    if response.status_code != 200:
        return response
    
    body = await req.json()
    content_field = body.get('contentField', os.environ["SEARCHSERVICE_FIELD_CONTENT"])
    key_field = body.get('keyField', os.environ["SEARCHSERVICE_FIELD_KEY"])
    data = json.loads(response.body)
    question = body.get('search', '')

    answer = oai.get_openai_answer(question, oai.get_context(data, content_field, key_field), os.environ["OPENAI_API_DEFAULT_MODEL"])

    semantic_answer_replacement = { 
            "@search.answers": [
                {
                    "key": "openai",
                    "text": answer,
                    "highlights": answer,
                    "score": 0,
                }
            ]
        }
    
    data.update(semantic_answer_replacement)
    headers = rh.clean_headers(response.headers, keysToRemove=["Content-Length", "Content-Encoding"])
    #TODO: add headers to response
    return Response(content=json.dumps(data), status_code=response.status_code)

@app.post("/indexes/{index}/docs/index")
async def index_docs(req: Request):
    body = await req.json()
    documents = body.get('value', [])
    content_field = body.get('contentField', os.environ["SEARCHSERVICE_FIELD_CONTENT"])
    return oai.generate_vector(documents, content_field, os.environ["OPENAI_API_EMBEDDING_MODEL"]).to_dict(orient='records')

@app.api_route("/{path_name:path}")
async def catch_all(request: Request) -> Response:
    return await rh.forward_req(request)

async def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    """Each request is redirected to the ASGI handler."""
    return await func.AsgiMiddleware(app).handle_async(req, context)